// Your Name
// NetId

// Useage statement
#define USAGE_MSG "ERROR! Usage: ./formattxt -L | -U | -T | -t | -R SYMBOLS [-W WORD]\n\n"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "helpers1.h"