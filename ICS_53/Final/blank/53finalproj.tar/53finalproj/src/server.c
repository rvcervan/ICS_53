int main() {
    // You got this!
    return 0;
}